# Driver: Ismarie Birriel
# Navigator: Musa Al Sathman Gazi
# Human Uno player has classes that override uno.py to act as human player for uno game

# import from uno (Uno, UnoPlayer, Color, CardType classes)
from uno import Color, UnoPlayer, CardType, Uno, PublicGameState, Card
from enum import IntEnum, auto

class Group24Human(UnoPlayer):      
    def __init__(self, name):
        UnoPlayer.__init__(self,name)

    def choose_card(self, state):
        UnoPlayer.choose_card(self,state)
        self.state = state
        top_card = PublicGameState.get_top_card(state)
        top_card_type = Card.get_type(top_card)
        top_card_color = Card.get_color(top_card)
        top_card_number = Card.get_number(top_card)
        called_color = PublicGameState.get_called_color(state)
        i = 0
        print('Top card: ', top_card)
        if Card.is_wild(top_card):
            print('Called color is', called_color)
            print('Your hand:')
            for card in range(UnoPlayer.get_num_cards(self)): 
                print(f'{i}. {self.hand[i]}')
                i += 1
            else:
                print(f'{i}. Draw a card and skip your turn')
                
            user_pick = int(input("Which one will you pick? "))
            
            while user_pick > len(self.hand):
                user_pick = int(input("Which one will you pick? "))

            card = self.hand[user_pick]
            card_color = Card.get_color(card)
            
            if user_pick == len(self.hand):
                print("Passed")
                return None
            while card_color != called_color:
                user_pick = int(input("Which one will you pick? "))
            
                while user_pick > len(self.hand):
                    user_pick = int(input("Which one will you pick? "))
                if user_pick == len(self.hand):
                    print("Passed")
                    return None

                card = self.hand[user_pick]
                card_color = Card.get_color(card)
            return card
        else:
            print('Your hand:')
            for card in range(UnoPlayer.get_num_cards(self)): 
                print(f'{i}. {self.hand[i]}')
                i += 1
            else:
                print(f'{i}. Draw a card and skip your turn')
            user_pick = int(input("Which one will you pick? "))
            while user_pick > len(self.hand):
                user_pick = int(input("Which one will you pick? "))
            
            if user_pick == len(self.hand):
                print("Passed")
                return None

            
            card = self.hand[user_pick]
            card_type = Card.get_type(card)
            card_color = Card.get_color(card)
            card_number = Card.get_number(card)
            if Card.is_wild(card):
                print('Wild card')
                return card

            while top_card_color != card_color:
                if card_type == CardType.NUMBER and top_card_type == CardType.NUMBER:
                    if card_number == top_card_number:
                        break
                if card_type != CardType.NUMBER and top_card_type != CardType.NUMBER :
                    if card_type == top_card_type:
                        break
                print('Illegal move')

                user_pick = int(input("Which one will you pick? "))
                if user_pick == len(self.hand):
                    print("Passed")
                    return None
                card = self.hand[user_pick]
                card_type = Card.get_type(card)
                card_color = Card.get_color(card)
                card_number = Card.get_number(card)
                if Card.is_wild(card):
                    print('Wild card')
                    return card            
            return card
            
    def call_color(self, state):
        UnoPlayer.call_color(self,state)
        self.state = input('What color do you call (red, blue, green, or yellow)? ')
        while self.state not in ['red', 'blue', 'green', 'yellow']:
            self.state = input('What color do you call (red, blue, green, or yellow)? ')
        if self.state == 'red':
            return Color.RED
        if self.state == 'blue':
            return Color.BLUE
        if self.state == 'green':
            return Color.GREEN
        if self.state == 'yellow':
            return Color.YELLOW


