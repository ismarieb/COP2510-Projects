# Driver: Musa Al Satham Gazi
# Navigator: Ismarie Birriel
# represents an AI uno player

from group24human import Group24Human
from uno import Uno, UnoPlayer, CardType, Color, PublicGameState, Card

class Group24AI(UnoPlayer):
    def __init__(self, name):
        UnoPlayer.__init__(self,name)

    def choose_card(self, state):
        UnoPlayer.choose_card(self, state)
        self.state = state
        top_card = PublicGameState.get_top_card(state)
        top_card_type = Card.get_type(top_card)
        top_card_color = Card.get_color(top_card)
        top_card_number = Card.get_number(top_card)
        called_color = PublicGameState.get_called_color(state)
        for card in self.hand:
            turn = 0
            while turn < 1:
                card_type = Card.get_type(card)
                card_color = Card.get_color(card)
                card_number = Card.get_number(card)
                if top_card_color != card_color:
                    if called_color == card_color:
                        return card
                    elif Card.is_wild(card):
                        return card
                    elif top_card_type == card_type and top_card_number == card_number:
                        return card
                elif top_card_color == card_color:
                    if top_card_number == card_number:
                        return card
                    elif top_card_type == card_type:
                        return card
                    return card
                turn += 1
        else:
            return None               
        

    def call_color(self, state):
        UnoPlayer.call_color(self,state)
        self.state = {'blue':0,'green':1,'red':2,'yellow':3,'none':4}
        card = self.hand[0]
        card_color = Card.get_color(card)
        if card_color.value == self.state['red']:
            return Color.RED
        if card_color.value == self.state['blue']:
            return Color.BLUE
        if card_color.value == self.state['green']:
            return Color.GREEN
        if card_color.value == self.state['yellow']:
            return Color.YELLOW
