# Driver : Ismarie Birriel
# Navigator : Dang Bui
# Prompts user to enter two real numbers and output the quadratic
# equation of multiplying the two zeros

import math
zero1 = float(input('Enter first zero: '))
zero2 = float(input('Enter second zero: '))
sBB = math.floor(zero1 + zero2)
sCC = math.floor(zero1 * zero2)
# still need to figure out having 2 digits for sCC and sBB form
print(f'Equation: y = x**2 + {sBB:0=+3.0f}x + {sCC:0=+3.0f}')
