# Driver : Dang Bui
# Navigator : Ismarie Birriel
# Prompts user to input quadratic equation and program calculates
# what the roots of the equation are

quadratic_equation = input('Enter quadratic equation \
in the form y = x**2 + sBBx + sCC: ')
b = float(quadratic_equation[11:14])
c = float(quadratic_equation[18:21])
check_function = b**2 - 4 * c
x1 = (-b + (b * b - 4 * c)**(1/2)) / 2
x2 = (-b - (b * b - 4 * c)**(1/2)) / 2
if check_function < 0:
    print('This equation has no zeros!')
else:
    print(f'The zeros of this equation are at {x1} and {x2}')




