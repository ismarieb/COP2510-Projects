# Driver : Ismarie Birriel
# Navigator : Dang Bui
# Program asks user for mass and angle and program
# calculates the force to push the cart up a hill.

import math

Mass = float(input('Type in a mass in kg: '))
Angle = float(input('Type in an angle in degrees: '))
G = 9.8
Radians = math.radians(Angle)
Force = Mass * G * math.sin(Radians)
print(f'You will need a force of {Force:.1f} N to push the cart.')
