# Driver : Dang Bui
# Navigator : Ismarie Birriel
# Program asks user to input xyz components for 2 vectors and
# calculates the cross - product of two vectors

vec1 = list(int(x) for x in input("Enter a 3D vector, with the 3 coordinates separated by spaces:  ").split())
vec2 = list(int(x) for x in input("Enter a 3D vector, with the 3 coordinates separated by spaces:  ").split())
cross_productx = vec1[1] * vec2[2] - vec1[2] * vec2[1] 
cross_producty  = vec1[2] * vec2[0] - vec1[0] *vec2[2]
cross_productz = vec1[0] * vec2[1] - vec1[1] * vec2[0]
print (f'The cross-product is ({cross_productx:.0f}, {cross_producty:.0f}, \
{cross_productz:.0f}).')
