# Driver: Ismarie Birriel
# Navigator: Shamar Patterson
# Write a Python script to calculate interest compounded continuously,
# according to the formula A = P * (e ** (r * t))
# e requires importing math library
import math
principalAmount = int(input('What is the principal amount? '))
rate = float(input('What is the rate? '))
time = int(input('How many years are you investing? '))
e = math.exp(rate * time)
amount = principalAmount * e
amount = round(amount, 2)
print('After interest, you will have $', end='')
print(amount, end='')
print('.')
