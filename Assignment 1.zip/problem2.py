# Driver: Ismarie Birriel
# Navigator: Shamar Patterson
# Write a Python script that takes in the last two names of newlyweds
# and prints 4 possible married names for them
lastName1 = input('What is your last name? ')
lastName2 = input("What is your partner's last name? ")
optionA = lastName1
optionB = lastName2
optionC = lastName1 + '-' + lastName2
optionD = lastName2 + '-' + lastName1
print('Possible married last names: ' + optionA + ', ' + optionB + ', ' \
      + optionC + ', and ' + optionD)
