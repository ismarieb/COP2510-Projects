# Driver: Shamar Patterson 
# Navigator: Ismarie Birriel
# Script that prints 3 emojis using escape codes
# First emoji represents a place, second represents weather, third is a face
print('\U0001F3DD''\U00002600''\U0001F601')
🏝☀😁
