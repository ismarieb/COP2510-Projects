# Driver: Shamar Patterson 
# Navigator: Ismarie Birriel
# Program that caculates compound interest using the formula A = P(1 + r/n)^nt
principal = int(input('What is the principal? '))
rate = float(input('What is the rate? '))
periods = int(input('How many compounding periods?' ))
years = int(input('How many years are you investing? '))
A = (principal * (1 + (rate/periods))**(periods*years))
final = round(A,2)
print('At the end, you will have $',end='')
print(final,end='')
print('.')
